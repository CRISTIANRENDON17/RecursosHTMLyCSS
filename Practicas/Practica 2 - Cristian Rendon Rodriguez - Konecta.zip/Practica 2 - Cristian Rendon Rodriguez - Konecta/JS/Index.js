function BorrarForm() {
    form = document.getElementById("form");
    Botones = document.getElementById("Botones-Form");
    Botones.innerHTML = '';
    form.innerHTML = '';
    Botones.preventDefault();
    form.preventDefault();
}

function Funcion1() {

    Botones = document.getElementById("Botones-Form");
    form = document.getElementById("form");

    form.innerHTML = '' +
        '  <div class="form-group">' +
        '  <label> <h3>FORMULARIO</h3> </label>' +
        '  <br>' +
        '  <label for="Identificacion">Numero de Identificacion</label>' +
        '  <input type="number" class="form-control" id="Identificacion" placeholder="Identificacion">' +
        '  <small id="IdentificacionHelp" class="form-text text-muted">Recuerde que la identificacion es entre 7 a 10' +
        '    cifras</small>' +

        '  <label for="Celular">Numero de Celular</label>' +
        '  <input type="number" class="form-control" id="Celular" placeholder="Celular">' +
        ' <small id="CelularHelp" class="form-text text-muted">Recuerde que el numero de Celular tiene 10 cifras</small>' +

        '  <label for="Area-Operacion">Area/Operacion</label>' +
        '  <input type="text" class="form-control" id="Area-Operacion" placeholder="Area Operacion">' +
        '  <small id="Area-OperacionHelp" class="form-text text-muted">Recuerde poner su Area/Operacion</small>' +

        '  <label for="Donde-te-encuentras">¿Donde te encuentras?</label>' +
        '  <select class="form-control" name="Donde-te-encuentras" placeholder="Donde te encuentras" name="Donde-te-encuentras" id="Donde-te-encuentras">' +
        '    <option value="0">Donde te encuentras...</option>' +
        '    <option value="1">Medellin</option>' +
        '    <option value="2">Apartado</option>' +
        '    <option value="3">Jardin</option>' +
        '    <option value="4">Otro</option>' +
        '  </select>' +
        '  <small id="Donde-te-encuentrasHelp" class="form-text text-muted">Si necesitamos contactarnos telefonicamente, indicanos' +
        '    ¿donde te encuentras?</small>' +

        '    <label for="Nombres-y-Apellidos">Nombres y Apellidos</label>' +
        '    <input type="text" class="form-control" id="Nombres-y-Apellidos" placeholder="Nombres y Apellidos">' +
        '    <small id="Nombres-y-ApellidosHelp" class="form-text text-muted">Recuerde poner su Nombres y Apellidos completos</small>' +

        '    <label for="Correo">Correo</label>' +
        '    <input type="text" class="form-control" id="Correo" placeholder="Correo">' +
        '    <small id="CorreoHelp" class="form-text text-muted">Recuerde ingresar su Correo</small>' +

        '    <label for="Cargo">Cargo</label>' +
        '    <input type="text" class="form-control" id="Cargo" placeholder="Cargo">' +
        '    <small id="CargoHelp" class="form-text text-muted">Recuerde poner el Cargo que quiere ocupar</small>' +

        '    <label for="Horario">Horario en el que te podemos contactar</label>' +
        '    <input type="datetime-local" class="form-control" id="Horario" placeholder="Horario de Contacto">' +
        '    <small id="HorarioHelp" class="form-text text-muted">Recuerde poner el Horario en el que te podemos contactar</small>' +
        '   </div>' +
        '   <div class="alert alert-primary" role="alert">' +
        '   <h4 id="Info"></h4></div>';

    Botones.innerHTML =
        '<div class="margin"><button id="Ingresar-Formulario" type="submit" class="btn btn-primary" onclick="EnviarFuncion1()">INGRESAR</button></div>' +
        '<div class="margin"><button id="Limpiar-formulario" type="submit" class="btn btn-success"  onclick="LimpiarFuncion1()">LIMPIAR</button></div>' +
        '<div class="margin"><button id="Limpiar-formulario" type="submit" class="btn btn-danger"  onclick="BorrarForm()">ELIMINAR</button><div>';

    Botones.preventDefault();
    form.preventDefault();
}

//document.getElementById('Inicio').addEventListener('click', Funcion1);

function LimpiarFuncion1() {
    document.getElementById("Identificacion").value = "";
    document.getElementById("Celular").value = "";
    document.getElementById("Area-Operacion").value = "";
    document.getElementById("Donde-te-encuentras").value = "Donde te encuentras...";
    document.getElementById("Nombres-y-Apellidos").value = "";
    document.getElementById("Correo").value = "";
    document.getElementById("Cargo").value = "";
    document.getElementById("Horario").value = "";

    var Informacion = document.getElementById("Info");
    Informacion.innerHTML = "Registro Limpiado";
    Informacion.preventDefault();
}
//document.getElementById('Limpiar-formulario').addEventListener('click', LimpiarFuncion1);



function EnviarFuncion1() {
    var text = "";
    var Identificacion = document.getElementById("Identificacion").value;
    var Celular = document.getElementById("Celular").value;
    var Area_Operacion = document.getElementById("Area-Operacion").value;
    var Donde_te_encuentras = document.getElementById("Donde-te-encuentras").value;
    var Nombres_y_Apellidos = document.getElementById("Nombres-y-Apellidos").value;
    var Correo = document.getElementById("Correo").value;
    var Cargo = document.getElementById("Cargo").value;
    var Horario = document.getElementById("Horario").value;

    if (parseInt(Identificacion) < 999999) {
        text = "→ La Identificacion tiene que ser mayor o igual a 7 cifras <br> \n";
    } else if (parseInt(Identificacion) > 10000000000) {
        text = "→ La Identificacion tiene que ser menor o igual a 10 cifras <br> \n";

    } else if (Identificacion == "") {
        text = "→ Ingrese la Identificacion <br> \n";
    }
    if (parseInt(Celular) < 999999999 || parseInt(Celular) > 10000000000) {
        text = text + "→ El numero de telefono tiene que tener 10 cifras <br> \n";
    } else if (Celular == "") {
        text = text + "→ Ingrese el numero de Celular <br>\n";
    }
    if (Area_Operacion == "") {
        text = text + "→ Ingrese un area de operacion <br>\n";
    }
    if (Donde_te_encuentras == "0") {
        text = text + "→ Ingrese Donde se encuentra <br>\n";
    }
    if (Nombres_y_Apellidos == "") {
        text = text + "→ Ingrese Su Nombres y Apellidos <br>\n";
    }
    if (Cargo == "") {
        text = text + "→ Ingrese El cargo que desea <br>\n";
    }
    var expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (Correo == "") {
        text = text + "→ Ingrese el correo electronico <br>\n";
    } else if (!expr.test(Correo)) {
        text = text + "→ La dirección de correo " + Correo + " es incorrecta. <br> \n";
    }
    var hoy = new Date();
    if (Horario == "") {
        text = text + "→ Ingrese El horario que se le puede llamar <br> \n";
    } else if (hoy > Date.parse(Horario)) {
        text = text + "→ La fecha ingresada ya paso, vuelva a ingresar fecha"
    } 
    if (text == "") {
        text = text + "→ Los Datos Fueron Ingresados con Exito! <br>";
    }

    var Informacion = document.getElementById("Info");
    Informacion.innerHTML = text;
    Informacion.preventDefault();
}

//document.getElementById('Ingresar-Formulario').addEventListener('click', EnviarFuncion1);

function BorrarCalculadora() {
    BotonesCalculadora = document.getElementById("Botones-Calculadora");
    form2 = document.getElementById("form2");
    form2.innerHTML = '';
    BotonesCalculadora.innerHTML = '';
    BotonesCalculadora.preventDefault();
    form2.preventDefault();
}


function Funcion2() {

    BotonesCalculadora = document.getElementById("Botones-Calculadora");
    form2 = document.getElementById("form2");
    form2.innerHTML = ' ' +
        ' <div class="form-group">' +
        ' <label>' +
        '   <h3>CALCULADORA</h3>' +
        ' </label>' +
        ' <br>' +
        ' <div class="row">' +
        '   <div class="col-4">' +
        '     <label for="Identificacion">Valor A</label>' +
        '     <input type="number" class="form-control" id="Valor-A" placeholder="Ingresar Valor A">' +
        '   </div>' +
        '   <div class="col-4">' +
        '     <label for="Operador-label">Operador</label>' +
        '     <select class="form-control" name="Operador" placeholder="Operador"' +
        '        id="Operador">' +
        '       <option>Elija Operdor</option>' +
        '       <option value="+">Sumar (+)</option>' +
        '       <option value="-">Restar (-)</option>' +
        '       <option value="*">Multiplicar (*)</option>' +
        '       <option value="/">Dividir (/)</option>' +
        '     </select>' +
        '   </div>' +
        '   <div class="col-4">' +
        '       <label for="Valor-B">Valor B</label>' +
        '       <input type="number" class="form-control" id="Valor-B" placeholder="Ingresar Valor B">' +
        '   </div>' +
        ' </div>' +
        '</div>' +
        '<div  class="alert alert-primary" role="alert">' +
        ' <h4 id="Resultado"></h4>' +
        ' </div>';

    BotonesCalculadora.innerHTML =
        '<div class="margin"><button id="Ingresar-Formulario" type="submit" class="btn btn-primary" onclick="OperarFuncion2()">OPERAR</button></div>' +
        '<div class="margin"><button id="Limpiar-formulario" type="submit" class="btn btn-success"  onclick="LimpiarFuncion2()">LIMPIAR</button></div>' +
        '<div class="margin"><button id="Limpiar-formulario" type="submit" class="btn btn-danger"  onclick="LimpiarFuncion2()">ELIMINAR</button><div>';

    BotonesCalculadora.preventDefault();
    form2.preventDefault();

}

function LimpiarFuncion2() {
    document.getElementById("Valor-A").value = "";
    document.getElementById("Valor-B").value = "";
    document.getElementById("Operador").value = "Elija Operdor";

    var Resultado = document.getElementById("Resultado");
    Resultado.innerHTML = "";
    Resultado.preventDefault();
}

function OperarFuncion2() {
    var text2 = "";
    var ValorA = document.getElementById("Valor-A").value;
    var ValorB = document.getElementById("Valor-B").value;
    var Operador = document.getElementById("Operador").value;

    if (Operador == "Elija Operdor" && Number.isInteger(parseInt(ValorA)) && Number.isInteger(parseInt(ValorB))) {
        text2 = "Primero Elija Un operador antes de operar";
    } else if (Operador == "Elija Operdor" && !Number.isInteger(parseInt(ValorA)) && Number.isInteger(parseInt(ValorB))) {
        text2 = "Elija un operador y llene el campo Valor A";
    } else if (Operador == "Elija Operdor" && Number.isInteger(parseInt(ValorA)) && !Number.isInteger(parseInt(ValorB))) {
        text2 = "Elija un operador y llene el campo Valor B";
    } else if (Operador != "Elija Operdor" && !Number.isInteger(parseInt(ValorA)) && !Number.isInteger(parseInt(ValorB))) {
        text2 = "Llene el campo Valor A y llene el campo Valor B";
    } else if (Operador != "Elija Operdor" && Number.isInteger(parseInt(ValorA)) && !Number.isInteger(parseInt(ValorB))) {
        text2 = "Llene el campo Valor B";
    } else if (Operador != "Elija Operdor" && !Number.isInteger(parseInt(ValorA)) && Number.isInteger(parseInt(ValorB))) {
        text2 = "Llene el campo Valor A";
    } else if (Operador == "Elija Operdor" && !Number.isInteger(parseInt(ValorA)) && !Number.isInteger(parseInt(ValorB))) {
        text2 = "Llene todos los campos";
    } else {
        if (Operador == "+") {
            text2 = "Respuesta = " + (parseInt(ValorA) + parseInt(ValorB));
        } else if (Operador == "-") {
            text2 = "Respuesta = " + (parseInt(ValorA) - parseInt(ValorB));
        }
        if (Operador == "*") {
            text2 = "Respuesta = " + (parseInt(ValorA) * parseInt(ValorB));
        }
        if (Operador == "/") {
            text2 = "Respuesta = " + (parseInt(ValorA) / parseInt(ValorB));
        }
    }
    var Resultado = document.getElementById("Resultado");
    Resultado.innerHTML = text2;
    Resultado.preventDefault();
}